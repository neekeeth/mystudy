#pragma once
#include <cmath>
#include <cassert>
#define PI 3.1415

class Circle: virtual public Shape {
    std::string type_name = "Circle";
    double r = 0;

    public:

    Circle (double in_r) : r(in_r) {
        assert(in_r >= 0);
    }
    virtual double square() {
        return PI * (r * r);
    }; 
    virtual Bounding_box_dimensions dimensions() {
        Bounding_box_dimensions new_box;
            new_box.heigth = r * 2;
            new_box.width = r * 2;
        return new_box;
    };
    virtual std::string type (){
        return type_name;
    };
};