#pragma once
#include <cmath>

class Rectangle: virtual public Shape{
    std::string type_name = "Rectangle";
    double a = 0;
    double b = 0;

    public:
    Rectangle (double in_a, double in_b) : a(in_a), b(in_b) {
        assert(in_a >= 0);
        assert(in_b >= 0);
    }
    
    virtual double square() {
        return a * b;
    }; 
    virtual Bounding_box_dimensions dimensions() {
        Bounding_box_dimensions new_box;
            new_box.heigth = a;
            new_box.width = b;
        return new_box;
    };
    virtual std::string type (){
        return type_name;
    };
};