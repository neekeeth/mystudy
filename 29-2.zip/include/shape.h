#pragma once
#include <string>
class Shape {
    public:
    Shape () {}
    virtual ~Shape() {}
    struct Bounding_box_dimensions {
        double heigth = 0;
        double width = 0;
    };
    virtual double square() = 0; 
    virtual Bounding_box_dimensions dimensions() = 0;
    virtual std::string type() = 0;
};