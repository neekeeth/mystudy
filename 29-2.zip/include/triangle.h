#pragma once
#include <cmath>
#include <cassert>
#include "shape.h"
#include <string>

class Triangle: virtual public Shape {
    std::string type_name = "Triangle";
    double a = 0;
    double b = 0;
    double c = 0;
    double p = (a + b + c) / 2;
    double r = a * b * c / (4 * sqrt(p*(p - a)*(p - b)*(p - c)));

    public:
    Triangle (double in_a, double in_b, double in_c) : a(in_a), b(in_b), c(in_c) {
        assert(in_a >= 0);
        assert(in_b >= 0);
        assert(in_c >= 0);
    }
    virtual double square() {
        return sqrt(p * (p - a) * (p - b) * (p - c));
    }; 
    virtual Bounding_box_dimensions dimensions() {
        Bounding_box_dimensions new_box;
            new_box.heigth = r * 2;
            new_box.width = r * 2;
        return new_box;
    };
    virtual std::string type (){
        return type_name;
    };
};