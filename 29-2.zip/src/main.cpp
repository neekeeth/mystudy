#include <iostream>
#include "triangle.h"
#include "rectangle.h"
#include "circle.h"
#include "shape.h"

void printParams(Shape *shape) { 
        std::cout <<"Type: " << shape->type() << std::endl;
        std::cout <<"Square: " << shape->square() << std::endl;
        std::cout <<"Height: " << shape->dimensions().heigth << std::endl;
        std::cout <<"Width: " << shape->dimensions().width << std::endl;
    }

int main(){

    Shape* new_circle = new Circle(2);
    Shape* new_triangle = new Triangle(2, 2, 2);
    Shape* new_rectangle = new Rectangle(2, 2);
    printParams(new_circle);
    printParams(new_triangle);
    printParams(new_rectangle);

    delete(new_circle);
    delete(new_triangle);
    delete(new_rectangle);
}
