#include <iostream>
#include <string>
#include <cpr/cpr.h>

int main(){
    std::string in_text = cpr::Get(cpr::Url("http://httpbin.org/html")).text;
    for (unsigned i = in_text.find("<h1>") + 4; i < in_text.find("</h1>"); ++i) {
        std::cout << in_text[i];
    }
    std::cout << std::endl;
}
