#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <cpr/cpr.h>

std::string get_url(std::map <std::string, std::string>& args) {
    std::string url_to_send = "http://httpbin.org/get?";
    for(std::map <std::string, std::string>::iterator it_args = 
            args.begin(); it_args != args.end(); ++it_args) {
        url_to_send += it_args->first + "=" + it_args -> second;
        if(it_args != args.end()) url_to_send += "&";         
    }
    url_to_send[url_to_send.length()-1] = 0;
    return url_to_send;
}

int main(){
    std::string parameter = "";
    std::string value = "";
    std::string method = "";
    std::cout << "Enter a few pair of arguments you want to send:" << std::endl;
    std::vector <cpr::Pair> pairs;
    std::map <std::string, std::string> args;
    while (parameter != "post" &&
            parameter != "get") {
        std::cout << "Parameter:";
        std::cin >> parameter;
        std::cout << std::endl;
        if(parameter == "post" ||
                parameter == "get") {
            method = parameter;
            continue;
        }
        std::cout << "Value:";
        std::cin >> value;
        std::cout << std::endl;
            while(value == "post" ||
                    value == "get") {
                std::cout << "Second part of pair cannot be 'post' or 'get'" << std::endl;
                std::cout << "Try again" << std::endl;
                std::cout << "Second part:";
                std::cin >> value;
                std::cout << std::endl;
            }
        pairs.push_back(cpr::Pair(parameter, value));
        args.insert({parameter, value});
    }

    std::vector <cpr::Pair>::iterator it = pairs.begin();

    if(method == "get") {
        cpr::Response r = cpr::Get(cpr::Url(get_url(args)));
        std::cout << r.text << std::endl;
    } else if(method == "post") {
        cpr::Response r = cpr::Post(cpr::Url("http://httpbin.org/post"), 
                    cpr::Payload(it, pairs.end()));
        std::cout << r.text << std::endl;
    }

    return 0;

}
