#include <QApplication>
#include <QSlider>
#include <QPixmap>
#include <QVBoxLayout>
#include <QPaintEvent>
#include <QPainter>

class Circle : public QWidget {
    Q_OBJECT
public:
    Circle (QWidget* parent);
    void paintEvent (QPaintEvent* e) override;
    QSize sizeHint () const override;
    QSize minimumSizeHint () const override;
    void change_color (int value);
private:
    QPixmap currentColor;
    QPixmap greenColor;
    QPixmap yellowColor;
    QPixmap redColor;
};

Circle::Circle (QWidget* parent) {
    setParent (parent);
    setToolTip ("Circle");
    setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    greenColor = QPixmap (":/green.png");
    yellowColor = QPixmap (":/yellow.jpeg");
    redColor = QPixmap (":/red.png");
    currentColor = greenColor;
    setGeometry(currentColor.rect());
}
void Circle::paintEvent(QPaintEvent* e) {
    QPainter p (this);
    p.drawPixmap (e -> rect(), currentColor);
}
QSize Circle::sizeHint () const {
    return QSize (395, 395); // set widget size
}

QSize Circle::minimumSizeHint () const {
    return sizeHint (); // set minimum widget size. We just use the last function - sizeHint()
}
void Circle::change_color (int value) {
    if (value >= 0 && value <= 30) {
        currentColor = greenColor;
        update ();
    } else if (value >=31 && value <= 60) {
        currentColor = yellowColor;
        update ();
    } else if (value >= 61 && value <= 100) {
        currentColor = redColor;
        update ();
    } else return;
}


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QWidget* window = new QWidget;
    window -> move (500, 300);
    auto* circle = new Circle (window);
    circle->setFixedSize(395, 395);
    auto* slider = new QSlider (Qt::Horizontal, window);
    slider -> setMinimum(0);
    slider -> setMaximum(100);
    auto* layout = new QVBoxLayout (window);
    layout -> addWidget(circle);
    layout -> addWidget(slider);
    QObject::connect(slider, &QSlider::valueChanged, circle, &Circle::change_color);
    window -> show ();
    return a.exec();
}

#include <main.moc>
