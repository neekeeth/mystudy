#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QMainWindow>
#include <QLineEdit>
#include <QTextEdit>1

class Calculator : public QMainWindow {
    Q_OBJECT
    int first_value = 0;
    int second_value = 0;
    int result = 0;
public:
    QLineEdit* new_line = nullptr;
    QLineEdit* input_line_1 = nullptr;
    QLineEdit* input_line_2 = nullptr;
    Calculator (QWidget* parent = nullptr) : QMainWindow (parent){}
public slots:
    void add_value1 () {
        std::string line = (input_line_1 -> text()).toStdString();
        if (line.length() == 0) {
            input_line_1 -> setText(0);
            first_value = 0;
            return;
        }
        for (auto ch : line) {
            if(ch < 48 || ch > 57) {
                input_line_1 -> setText(0);
                first_value = 0;
                return;
            }
        }
        first_value = std::stoi(line);
    };
    void add_value2 () {
        std::string line = (input_line_2 -> text()).toStdString();
        if (line.length() == 0) {
            input_line_2 -> setText(0);
            second_value = 0;
            return;
        }
        for (auto ch : line) {
            if(ch < 48 || ch > 57) {
                input_line_2 -> setText(0);
                second_value = 0;
                return;
            }
        }
        second_value = std::stoi(line);
    };
    void add_plus_sign () {
        result = first_value + second_value;
        std::string str_res = std::to_string(result);
        new_line -> setText(str_res.c_str());
        result = 0;
    };
    void add_minus_sign () {
        result = first_value - second_value;
        std::string str_res = std::to_string(result);
        new_line -> setText(str_res.c_str());
        result = 0;
    };
    void add_mult_sign () {
        result = first_value * second_value;
        std::string str_res = std::to_string(result);
        new_line -> setText(str_res.c_str());
        result = 0;
    };
    void add_division_sign () {
        if (second_value > 0) result = first_value / second_value;
        std::string str_res = std::to_string(result);
        new_line -> setText(str_res.c_str());
        result = 0;
    };
};

#endif // CALCULATOR_H
