#include "mainwindow.h"
#include <QPushButton>
#include <QApplication>
#include "calculator.h"
#include "ui_mainwindow.h"


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Calculator w (nullptr);
    Ui:: MainWindow calc;
    calc.setupUi(&w);
    w.new_line = calc.lineEdit;
    w.input_line_1 = calc.input1;
    w.input_line_2 = calc.input2;
    w.show();
    return a.exec();
}

#include <main.moc>
