#include <QWebEngineView>
#include "ui_mainwindow.h" // for add ui window
#include "mainwindow.h"
#include <QtGui/QtGui>
#include <QPlainTextEdit>
#include <QApplication>
#include <QHBoxLayout>
#include <QSizePolicy>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QFileInfo>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow window;
    Ui::MainWindow window_ui;
    window_ui.setupUi(&window); // dont forget!!!
    QPlainTextEdit* text_edit = window_ui.plainTextEdit;
    text_edit -> setStyleSheet("background-color:#ffffff;"
                               "color: #000000;");
    QHBoxLayout* h_box =  window_ui.horizontalLayout;
    auto* web_view = new QWebEngineView (&window);
    h_box->addWidget(web_view);
    QSizePolicy web_view_size_policy (QSizePolicy::Expanding, QSizePolicy::Expanding);
    web_view_size_policy.setHorizontalStretch(1);
    web_view -> setSizePolicy(web_view_size_policy);
    web_view -> setStyleSheet("background-color:#ffffff;"
                              "color: #000000;");
    QFile out("index.html"); //just make file idk where
    QFileInfo out_info (out); //make info bout this file

    auto file_to_open = QUrl("file://" + out_info.absoluteFilePath()); //make url to open by webview

    if (!out.open(QIODevice::WriteOnly)) {
        QMessageBox::information(&window,"Erorr","There is no file to write!");
        return 1;
    }
    QTextStream in(&out); //text stream to write something to the file
    QObject::connect(text_edit, &QPlainTextEdit::textChanged, [&file_to_open, web_view, &out, &in, text_edit](){
        out.open(QIODevice::WriteOnly | QIODevice::Text);
        in << text_edit -> toPlainText();
        out.close();
        web_view -> load (QUrl(file_to_open));
    });
    window.show();
    return a.exec();
}
//#include <main.moc>
