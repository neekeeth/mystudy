/*designed by KEETH 09.02.2024*/

#include "mainwindow.h"


void change_button_size (QWidget& button) {
    button.setMaximumSize(button.QWidget::parentWidget() -> maximumWidth() / 9,
                          button.QWidget::parentWidget() -> maximumHeight() / 1.5);
    button.setMinimumSize(button.QWidget::parentWidget() -> minimumWidth() / 9,
                          button.QWidget::parentWidget() -> minimumHeight() / 1.5);
    button.setCursor(Qt::PointingHandCursor);
    button.setStyleSheet("background-color: #303030; color: #fff");
}
bool tempirature_change (QTextEdit& temperature_display, char& tempirature_scale, int value = 26, bool from_dialog = 0) {
    if (from_dialog) {
        if (value >= 16 || value <= 30) {
            tempirature_scale = 'C';
        }
    }
    bool changed = false;
    switch (tempirature_scale) {
        case 'C':
            if (temperature_display.toPlainText().toStdString() != "") {
                if (std::stoi((temperature_display.toPlainText()).toStdString()) <= 30 &&
                    std::stoi((temperature_display.toPlainText()).toStdString()) >= 16) {
                    if ((std::stoi((temperature_display.toPlainText()).toStdString()) <= 30 &&
                         std::stoi((temperature_display.toPlainText()).toStdString()) > 16 &&
                         value == -1) ||
                        (std::stoi((temperature_display.toPlainText()).toStdString()) < 30 &&
                         std::stoi((temperature_display.toPlainText()).toStdString()) >= 16 &&
                         value == 1)) {
                        temperature_display.setText((std::to_string(std::stoi((temperature_display.toPlainText()).toStdString()) + value) + ' ' + 'C').c_str());
                        changed = true;
                    } else if (value <= 30 && value >= 16) {
                        temperature_display.setText((std::to_string(value) + ' ' + 'C').c_str());
                        changed = true;
                    }
                } else if (value <= 30 && value >= 16) {
                    temperature_display.setText((std::to_string(value) + ' ' + 'C').c_str());
                    changed = true;
                }
            } else {
                if (value <= 30 && value >= 16) {
                    temperature_display.setText((std::to_string(value) + ' ' + 'C').c_str());
                    changed = true;
                }
            }
            temperature_display.setAlignment(Qt::AlignCenter);
            break;
        case 'F':
            if (std::stod((temperature_display.toPlainText()).toStdString()) <= 86 &&
                std::stod((temperature_display.toPlainText()).toStdString()) >= 60.8) {
                if ((std::stod((temperature_display.toPlainText()).toStdString()) <= 86 &&
                     std::stod((temperature_display.toPlainText()).toStdString()) > 60.8 &&
                     value == -1) ||
                    (std::stod((temperature_display.toPlainText()).toStdString()) < 86 &&
                     std::stod((temperature_display.toPlainText()).toStdString()) >= 60.8 &&
                     value == 1)) {
                    std::string f_scale_string = std::to_string(static_cast<double>(std::stod(temperature_display.toPlainText().toStdString()) + (value * 1.8)));
                    std::string empty = "";
                    temperature_display.setText(
                        (empty +
                         f_scale_string[0] +
                         f_scale_string[1] +
                         f_scale_string[2] +
                         f_scale_string[3] +
                         ' ' + 'F').c_str());
                    changed = true;
                }
            }
            temperature_display.setAlignment(Qt::AlignCenter);
            break;
        case 'K':
            if (std::stod((temperature_display.toPlainText()).toStdString()) <= 303.15 &&
                std::stod((temperature_display.toPlainText()).toStdString()) >= 289.15) {
                if ((std::stod((temperature_display.toPlainText()).toStdString()) <= 303.15 &&
                     std::stod((temperature_display.toPlainText()).toStdString()) > 289.15 &&
                     value == -1) ||
                    (std::stod((temperature_display.toPlainText()).toStdString()) < 303.15 &&
                     std::stod((temperature_display.toPlainText()).toStdString()) >= 289.15 &&
                     value == 1)) {
                    std::string k_scale_string = std::to_string((std::stod(temperature_display.toPlainText().toStdString()) + value));
                    std::string empty = "";
                    temperature_display.setText(
                        (empty +
                         k_scale_string[0] +
                         k_scale_string[1] +
                         k_scale_string[2] +
                         k_scale_string[3] +
                         k_scale_string[4] +
                         k_scale_string[5] +
                         ' ' + 'K').c_str());
                    changed = true;
                }
            }
            temperature_display.setAlignment(Qt::AlignCenter);
            break;
    }
    return changed;
}

bool humidity_change (QTextEdit& humidity_display, int value) {
    if (value < 0 || value > 100) return false;
    humidity_display.setText((std::to_string(value) + ' ' + '%').c_str());
    humidity_display.setAlignment(Qt::AlignCenter);
    return true;
}

bool pressure_change (QTextEdit& pressure_display, std::string& pressure_scale, int value, QPushButton& pressure_button) {
    if (pressure_scale == "kPa" && (value >= 700 || value <= 780)) {
        pressure_scale = "mmHg";
        pressure_button.setText("mmHg");
    }
    if (pressure_scale == "mmHg" && (value < 700 || value > 780)) return false;
    if (pressure_scale == "kPa" && (value < 93 || value > 104)) return false;
    pressure_display.setText((std::to_string(value) + ' ' + pressure_scale).c_str());
    return true;
}

bool pressure_scale_change (QTextEdit& pressure_display, std::string& pressure_scale) {
    bool changed = false;
    if (pressure_scale == "kPa") {
        pressure_scale = "mmHg";
        std::string mmHg_scale_string = std::to_string((std::stod(pressure_display.toPlainText().toStdString()) * 7.5006375541921));
        std::string intermediate = "";
        if (mmHg_scale_string[4] == '0' &&
            mmHg_scale_string[5] == '0') {
            std::string empty = "";
            pressure_display.setText(
                (empty +
                mmHg_scale_string[0] +
                mmHg_scale_string[1] +
                mmHg_scale_string[2] +
                 ' ' + pressure_scale).c_str());
        } else {
            std::string empty = "";
            pressure_display.setText(
                (empty +
                mmHg_scale_string[0] +
                mmHg_scale_string[1] +
                mmHg_scale_string[2] +
                mmHg_scale_string[3] +
                mmHg_scale_string[4] +
                mmHg_scale_string[5] +
                mmHg_scale_string[6] +
                mmHg_scale_string[7] +
                ' ' + pressure_scale).c_str());
        }
        changed = true;
        pressure_display.setAlignment(Qt::AlignCenter);
    } else if (pressure_scale == "mmHg") {
        pressure_scale = "kPa";
        std::string kpa_scale_string = std::to_string((std::stod(pressure_display.toPlainText().toStdString()) / 7.5006375541921));
        std::string empty = "";
        pressure_display.setText(
            (empty +
             kpa_scale_string[0] +
             kpa_scale_string[1] +
             kpa_scale_string[2] +
             kpa_scale_string[3] +
             kpa_scale_string[4] +
             kpa_scale_string[5] +
             kpa_scale_string[6] +
             kpa_scale_string[7] +
             ' ' + pressure_scale).c_str());
        changed = true;
        pressure_display.setAlignment(Qt::AlignCenter);
    }
    return changed;
}

bool tempirature_scale_change (QTextEdit& temperature_display, char& tempirature_scale) {
    bool changed = false;
    switch (tempirature_scale) {
        case 'C':
            temperature_display.setText(
                (std::to_string(static_cast<int>(std::stod(temperature_display.toPlainText().toStdString()) - 273.15)) + ' ' + 'C').c_str());
            changed = true;
            temperature_display.setAlignment(Qt::AlignCenter);
            break;
        case 'F': {
            std::string f_scale_string = std::to_string(static_cast<double>(std::stod(temperature_display.toPlainText().toStdString()) * 9 / 5 + 32));
            std::string empty = "";
            temperature_display.setText(
                (empty +
                f_scale_string[0] +
                f_scale_string[1] +
                f_scale_string[2] +
                f_scale_string[3] +
                ' ' + 'F').c_str());
            changed = true;
            temperature_display.setAlignment(Qt::AlignCenter);
            break;
        } case 'K': {
            std::string k_scale_string = std::to_string((std::stod(temperature_display.toPlainText().toStdString()) - 32) * 5 / 9 + 273.15);
            std::string empty = "";
            temperature_display.setText(
                (empty +
                k_scale_string[0] +
                k_scale_string[1] +
                k_scale_string[2] +
                k_scale_string[3] +
                k_scale_string[4] +
                k_scale_string[5] +
                ' ' + 'K').c_str());
            changed = true;
            temperature_display.setAlignment(Qt::AlignCenter);
            break;
        }
    }
    return changed;
}

/******************************************************LOAD PARAMETRES***************************************************************/

bool to_read_a_log (QTextEdit& temperature_display, char& tempirature_scale, QTextEdit& pressure_display, std::string& pressure_scale,
                    QTextEdit& humidity_display, QTextEdit& flow_direction_display, QPushButton& power_button, QPushButton& pressure_button,
                   QPushButton& tempirature_scale_button, bool& first_setup) {
    qDebug() << QDir::currentPath();
    QFile file (QDir::currentPath() + "logs.xml");
    if (file.open(QFile::ReadOnly | QFile::Text)) {
        QXmlStreamReader xmlReader;
        xmlReader.setDevice(&file);
        xmlReader.readNext();
        bool ok_log = false;
        unsigned tempirature_value = 0;
        unsigned pressure_value = 0;
        unsigned humidity_value = 0;
        std::string flow = "";
        char intermediate_temperature_scale;
        std::string intermediate_pressure_scale = "";
        while(!xmlReader.atEnd()) {
            if(xmlReader.isStartElement()) {
                if (xmlReader.name().toString() == "temperature_scale"){
                    std::string scale = xmlReader.readElementText().toStdString();
                    if (scale.length() == 1 && (scale[0] == 'C' || scale[0] == 'F' || scale[0] == 'K')) {
                        ok_log = true;
                        intermediate_temperature_scale = scale[0];
                    } else ok_log = false;
                }  else if(xmlReader.name().toString() == "temperature_value" && ok_log) {
                    ok_log = false;
                    std::string temp = "";
                    for (auto next : xmlReader.readElementText().toStdString()) {
                        if (next != ' ') temp += next;
                        else break;
                    }
                    switch (intermediate_temperature_scale) {
                    case 'C':
                        if (std::stoi(temp) >= 16 ||
                            std::stoi(temp) <= 30 ) {
                            ok_log = true;
                            tempirature_value = std::stoi(temp);
                        } else ok_log = false;
                        break;
                    case 'F':
                        if (std::stod(temp) >= 60.8 ||
                            std::stod(temp) <= 86 ) {
                            ok_log = true;
                            tempirature_value = std::stod(temp);
                        } else ok_log = false;
                        break;
                    case 'K':
                        if (std::stod(temp) >= 289.15 ||
                            std::stod(temp) <= 303.15 ) {
                            ok_log = true;
                            tempirature_value = std::stod(temp);
                        } else ok_log = false;
                        break;
                    }
                }  else if (xmlReader.name().toString() == "pressure_scale" && ok_log){
                    ok_log = false;
                    std::string temp = xmlReader.readElementText().toStdString();
                    if (temp == "mmHg" || temp == "kPa") {
                        intermediate_pressure_scale = temp;
                        ok_log = true;
                    } else ok_log = false;
                } else if (xmlReader.name().toString() == "pressure_value" && ok_log){
                    ok_log = false;
                    std::string temp = "";
                    for (auto next : xmlReader.readElementText().toStdString()) {
                        if (next != ' ') temp += next;
                        else break;
                    }
                    if (intermediate_pressure_scale == "mmHg") {
                        if((std::stoi(temp)) >= 700 &&
                            (std::stoi(temp)) <= 780) {
                            ok_log = true;
                            pressure_value = std::stoi(temp);
                        }
                    } else if (intermediate_pressure_scale == "kPa") {
                        if((std::stod(temp)) >= 93 &&
                            (std::stod(temp)) <= 104) {
                            ok_log = true;
                            pressure_value = std::stod(temp);
                        }
                    } else ok_log = false;
                } else if (xmlReader.name().toString() == "humidity_value" && ok_log){
                    ok_log = false;
                    std::string temp = "";
                    for (auto next : xmlReader.readElementText().toStdString()) {
                        if (next != ' ') temp += next;
                        else break;
                    }
                    if (std::stoi(temp) >= 0 &&
                        std::stoi(temp) <= 100){
                        ok_log = true;
                        humidity_value = std::stoi(temp);
                    } else ok_log = false;
                } else if (xmlReader.name().toString() == "flow_value" && ok_log){
                    ok_log = false;
                    std::string temp = xmlReader.readElementText().toStdString();
                    if (temp == "UP" || temp == "RIGHT" || temp == "LEFT") {
                        ok_log = true;
                        flow = temp;
                    } else ok_log = false;

                }
            }
            xmlReader.readNext();
        }
        if (ok_log) {
            std::string button_lable = "Scale "; //i know...
            tempirature_scale = intermediate_temperature_scale;
            tempirature_scale_button.setText((button_lable + intermediate_temperature_scale).c_str());
            temperature_display.setText((std::to_string(tempirature_value) + ' ' + intermediate_temperature_scale).c_str());
            temperature_display.setAlignment(Qt::AlignCenter);
            pressure_scale = intermediate_pressure_scale;
            pressure_button.setText(pressure_scale.c_str());
            pressure_display.setText((std::to_string(pressure_value) + ' ' + intermediate_pressure_scale).c_str());
            pressure_display.setAlignment(Qt::AlignCenter);
            humidity_display.setText((std::to_string(humidity_value) + ' ' + '%').c_str());
            humidity_display.setAlignment(Qt::AlignCenter);
            flow_direction_display.setText(flow.c_str());
            flow_direction_display.setAlignment(Qt::AlignCenter);
            file.close();
            return true;
        } else {
            file.close();
            return false;
        }
    } else return false;
}

    /******************************************************SAVE PARAMETRES***************************************************************/

void to_write_a_log (QTextEdit& temperature_display, char& tempirature_scale, QTextEdit& pressure_display, std::string& pressure_scale,
                    QTextEdit& humidity_display, QTextEdit& flow_direction_display) {
    QFile file (QDir::currentPath() + "logs.xml");
    file.open(QIODevice::WriteOnly);
    QXmlStreamWriter xmlWriter(&file);
    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();
    xmlWriter.writeStartElement("logs");
    xmlWriter.writeStartElement("temperature_scale");
    xmlWriter.writeCharacters(tempirature_scale);
    xmlWriter.writeEndElement();
    xmlWriter.writeStartElement("temperature_value");
    xmlWriter.writeCharacters(temperature_display.toPlainText().toStdString());
    xmlWriter.writeEndElement();
    xmlWriter.writeStartElement("pressure_scale");
    xmlWriter.writeCharacters(pressure_scale);
    xmlWriter.writeEndElement();
    xmlWriter.writeStartElement("pressure_value");
    xmlWriter.writeCharacters(pressure_display.toPlainText().toStdString());
    xmlWriter.writeEndElement();
    xmlWriter.writeStartElement("humidity_value");
    xmlWriter.writeCharacters(humidity_display.toPlainText().toStdString());
    xmlWriter.writeEndElement();
    xmlWriter.writeStartElement("flow_value");
    xmlWriter.writeCharacters(flow_direction_display.toPlainText().toStdString());
    xmlWriter.writeEndElement();
    xmlWriter.writeEndElement();
    xmlWriter.writeEndDocument();
    file.close();
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setMaximumSize(1024, 768);
    w.setMinimumSize(800, 600);
    w.setStyleSheet("background-color: #000;");
    std::string color_scheme = "black";

    QWidget main_widget {QWidget(&w)};
    w.setCentralWidget(&main_widget);
    main_widget.setMaximumSize(main_widget.QWidget::parentWidget() -> maximumWidth(),
                               main_widget.QWidget::parentWidget() -> maximumHeight());
    main_widget.setMinimumSize(main_widget.QWidget::parentWidget() -> minimumWidth(),
                               main_widget.QWidget::parentWidget() -> minimumHeight());
    QVBoxLayout main_vbox_lo {QVBoxLayout(&main_widget)};
    main_vbox_lo.setContentsMargins(0,0,0,0);
    main_vbox_lo.setAlignment(Qt::AlignTop);

    /**********************************************Display Widget******************************************************/

    QWidget display_widget {QWidget(&main_widget)};
    display_widget.setMaximumSize(display_widget.QWidget::parentWidget() -> maximumWidth(),
                               (display_widget.QWidget::parentWidget() -> maximumHeight())*2/3);
    display_widget.setMinimumSize(display_widget.QWidget::parentWidget() -> minimumWidth(),
                               (display_widget.QWidget::parentWidget() -> minimumHeight())*2/3);
    main_vbox_lo.addWidget(&display_widget);
    QVBoxLayout display_lo {QVBoxLayout(&display_widget)};
    display_lo.setAlignment(Qt::AlignCenter);


    //Temerature Display
    std::vector <QWidget*> displays;
    QHBoxLayout display_first_line {QHBoxLayout (&display_widget)};
    display_lo.addLayout(&display_first_line);
    QTextEdit temperature_display {QTextEdit(&display_widget)};
    temperature_display.setReadOnly(true);
    display_first_line.addWidget(&temperature_display);
    temperature_display.setMaximumSize(temperature_display.QWidget::parentWidget() -> maximumWidth() / 3,
                                  temperature_display.QWidget::parentWidget() -> maximumHeight() * 2 / 3);
    temperature_display.setMinimumSize(temperature_display.QWidget::parentWidget() -> minimumWidth() / 3,
                                  temperature_display.QWidget::parentWidget() -> minimumHeight() * 2 / 3);
    temperature_display.setCursorWidth(0);
    temperature_display.setStyleSheet("font-size: 65px;");
    temperature_display.setText("");
    temperature_display.setAlignment(Qt::AlignCenter);
    displays.push_back(&temperature_display);

    //Other Parametres on Display Widget
    QHBoxLayout display_second_line {QHBoxLayout (&display_widget)};
    display_lo.addLayout(&display_second_line);
    QTextEdit humidity_display {QTextEdit(&display_widget)};
    humidity_display.setReadOnly(true);
    humidity_display.setMaximumSize(humidity_display.QWidget::parentWidget() -> maximumWidth() / 6,
                                       humidity_display.QWidget::parentWidget() -> maximumHeight() / 3);
    humidity_display.setMinimumSize(humidity_display.QWidget::parentWidget() -> minimumWidth() / 6,
                                       humidity_display.QWidget::parentWidget() -> minimumHeight() / 3);
    display_second_line.addWidget(&humidity_display);
    humidity_display.setCursorWidth(0);
    humidity_display.setStyleSheet("font-size: 50px;");
    humidity_display.setText("");
    humidity_display.setAlignment(Qt::AlignCenter);
    displays.push_back(&humidity_display);

    QTextEdit flow_direction_display {QTextEdit(&display_widget)};
    flow_direction_display.setReadOnly(true);
    flow_direction_display.setMaximumSize(flow_direction_display.QWidget::parentWidget() -> maximumWidth() / 3,
                                    flow_direction_display.QWidget::parentWidget() -> maximumHeight() * 2 / 3);
    flow_direction_display.setMinimumSize(flow_direction_display.QWidget::parentWidget() -> minimumWidth() / 3,
                                    flow_direction_display.QWidget::parentWidget() -> minimumHeight() * 2 / 3);
    display_second_line.addWidget(&flow_direction_display);
    flow_direction_display.setStyleSheet("font-size: 100px;");
    flow_direction_display.setText("UP");
    flow_direction_display.setAlignment(Qt::AlignCenter);
    flow_direction_display.hide();
    displays.push_back(&flow_direction_display);

    QTextEdit pressure_display {QTextEdit(&display_widget)};
    pressure_display.setReadOnly(true);
    pressure_display.setMaximumSize(pressure_display.QWidget::parentWidget() -> maximumWidth() / 6+10,
                                       pressure_display.QWidget::parentWidget() -> maximumHeight() / 3);
    pressure_display.setMinimumSize(pressure_display.QWidget::parentWidget() -> minimumWidth() / 6+10,
                                       pressure_display.QWidget::parentWidget() -> minimumHeight() / 3);
    display_second_line.addWidget(&pressure_display);
    pressure_display.setStyleSheet("font-size: 50px;");
    pressure_display.setText("");
    pressure_display.setAlignment(Qt::AlignCenter);
    displays.push_back(&pressure_display);


    display_first_line.insertStretch(0, humidity_display.width());
    display_first_line.insertStretch(2, pressure_display.width());


   /**********************************************Сontrol Widget******************************************************/

    QWidget control_widget {QWidget(&main_widget)};
    control_widget.setMaximumSize(control_widget.QWidget::parentWidget() -> maximumWidth(),
                                  control_widget.QWidget::parentWidget() -> maximumHeight()/3);
    control_widget.setMinimumSize(control_widget.QWidget::parentWidget() -> minimumWidth(),
                                  control_widget.QWidget::parentWidget() -> minimumHeight()/3);
    main_vbox_lo.addWidget(&control_widget);
    QHBoxLayout control_lo {QHBoxLayout(&control_widget)};
    control_lo.setAlignment(Qt::AlignCenter);

    QPushButton power_button {QPushButton(&control_widget)};
    control_lo.addWidget(&power_button);
    change_button_size (power_button);
    power_button.setText("ON/OFF");

    bool system_is_on = false;

    std::vector <QPushButton*> control_buttons;
    QPushButton input_button {QPushButton(&control_widget)};
    control_lo.addWidget(&input_button);
    change_button_size (input_button);
    input_button.setText("Input \n parametres");
    control_buttons.push_back(&input_button);

    QPushButton application_color_button {QPushButton(&control_widget)};
    control_lo.addWidget(&application_color_button);
    change_button_size (application_color_button);
    application_color_button.setText("Change color");
    control_buttons.push_back(&application_color_button);
    application_color_button.hide();
    QPushButton plus_button {QPushButton(&control_widget)};
    control_lo.addWidget(&plus_button);
    change_button_size (plus_button);
    plus_button.setText("+");
    control_buttons.push_back(&plus_button);
    plus_button.hide();
    QPushButton minus_button {QPushButton(&control_widget)};
    control_lo.addWidget(&minus_button);
    change_button_size (minus_button);
    minus_button.setText("-");
    control_buttons.push_back(&minus_button);
    minus_button.hide();
    QPushButton tempirature_scale_button {QPushButton(&control_widget)};
    control_lo.addWidget(&tempirature_scale_button);
    change_button_size (tempirature_scale_button);
    tempirature_scale_button.setText("Scale C");
    control_buttons.push_back(&tempirature_scale_button);
    char tempirature_scale = 'C';
    tempirature_scale_button.hide();
    QPushButton pressure_button {QPushButton(&control_widget)};
    control_lo.addWidget(&pressure_button);
    change_button_size (pressure_button);
    pressure_button.setText("mmHg");
    control_buttons.push_back(&pressure_button);
    std::string pressure_scale = "mmHg";
    pressure_button.hide();
    QPushButton flow_button {QPushButton(&control_widget)};
    control_lo.addWidget(&flow_button);
    change_button_size (flow_button);
    flow_button.setText("Change \nFlow \nDirection");
    control_buttons.push_back(&flow_button);
    flow_button.hide();

    /******************************************************FIRST-SETUP MARKER***************************************************************/
    bool first_setup = true;

    /******************************************************READ A LOG-FILE***************************************************************/

    if (to_read_a_log(temperature_display, tempirature_scale, pressure_display, pressure_scale,
                  humidity_display, flow_direction_display, power_button, pressure_button,
                      tempirature_scale_button, first_setup)){
        first_setup = false;
        for(auto next : displays) {
            next -> show();
        }
        for (auto next : control_buttons) {
            next -> show();
        }
        system_is_on = true;
    }

    /******************************************************POWER BUTTON***************************************************************/
    QObject::connect(&power_button, &QPushButton::clicked, [&displays, &control_buttons, &system_is_on, &first_setup](){
        if (first_setup) {
            return;
        } else if (system_is_on) {
            for(auto next : displays) {
                next -> hide();
            }
            for (auto next : control_buttons) {
                next -> hide();
            }
            system_is_on = false;
        } else if (!system_is_on){
            for(auto next : displays) {
                next -> show();
            }
            for (auto next : control_buttons) {
                next -> show();
            }
            system_is_on = true;
        }
    });
    /******************************************************CHANGE COLOR BUTTON********************************************************/

    QObject::connect(&application_color_button, &QPushButton::clicked,[&w, &color_scheme, &temperature_display, &humidity_display, &pressure_display,
                                                                       &flow_direction_display, &power_button, &control_buttons](){
        if (color_scheme == "black") {
            w.setStyleSheet("background-color: #fff;");
            temperature_display.setStyleSheet("border: 0px; font-size: 65px; color: #000");
            humidity_display.setStyleSheet("border: 0px; font-size: 50px; color: #000");
            pressure_display.setStyleSheet("border: 0px; font-size: 45px; color: #000");
            flow_direction_display.setStyleSheet("border: 0px; font-size: 100px; color: #000");
            power_button.setStyleSheet("background-color: #000; color: #fff");
            for (auto next : control_buttons) next -> setStyleSheet("background-color: #000; color: #fff");
            color_scheme = "white";
        } else if (color_scheme == "white") {
            w.setStyleSheet("background-color: #000;");
            temperature_display.setStyleSheet("border: 0px; font-size: 65px; color: #fff");
            humidity_display.setStyleSheet("border: 0px; font-size: 50px; color: #fff");
            pressure_display.setStyleSheet("border: 0px; font-size: 45px; color: #fff");
            flow_direction_display.setStyleSheet("border: 0px; font-size: 100px; color: #fff");
            power_button.setStyleSheet("background-color: #303030; color: #fff");
            for (auto next : control_buttons) next -> setStyleSheet("background-color: #303030; color: #fff");
            color_scheme = "black";
        }
    });

    /******************************************************INPUT WINDOW***************************************************************/

        QObject::connect(&input_button, &QPushButton::clicked,[&a, &temperature_display, &tempirature_scale, &humidity_display, &pressure_display,
                                                               &pressure_scale, &input_button, &power_button, &first_setup, &pressure_button](){
            QDialog dialog_window {QDialog(nullptr)};
            dialog_window.resize(200, 100);
            QGridLayout dialog_lo {QGridLayout(&dialog_window)};
            QLabel tempirature_describer {QLabel(&dialog_window)};
            tempirature_describer.setText("Tempirature in Celcius: ");
            dialog_lo.addWidget(&tempirature_describer, 0, 0);
            QTextEdit tempirature_input_line {QTextEdit(&dialog_window)};
            tempirature_input_line.setText("26");
            tempirature_input_line.setAlignment(Qt::AlignCenter);
            dialog_lo.addWidget(&tempirature_input_line, 0, 1);
            QLabel humidity_describer {QLabel(&dialog_window)};
            humidity_describer.setText("Humidity in %: ");
            dialog_lo.addWidget(&humidity_describer, 1, 0);
            QTextEdit humidity_input_line {QTextEdit(&dialog_window)};
            humidity_input_line.setText("50");
            humidity_input_line.setAlignment(Qt::AlignCenter);
            dialog_lo.addWidget(&humidity_input_line, 1, 1);
            QLabel pressure_describer {QLabel(&dialog_window)};
            pressure_describer.setText("Pressure in mmHg: ");
            dialog_lo.addWidget(&pressure_describer, 2, 0);
            QTextEdit pressure_input_line {QTextEdit(&dialog_window)};
            pressure_input_line.setText("750");
            pressure_input_line.setAlignment(Qt::AlignCenter);
            dialog_lo.addWidget(&pressure_input_line, 2, 1);
            QPushButton accepted_button {QPushButton(&dialog_window)};
            accepted_button.setText("Send");
            dialog_lo.addWidget(&accepted_button, 3, 0, 1, 2);

            QObject::connect(&accepted_button, &QPushButton::clicked, [&dialog_window,&temperature_display, &tempirature_scale, &humidity_display,
                                                                       &tempirature_input_line, &input_button, &power_button, &first_setup, &pressure_scale,
                                                                       &humidity_input_line, &pressure_input_line, &accepted_button, &pressure_display,
                                                                        &pressure_button](){
                bool tempirature_changed = false;
                bool from_dialog = 1;
                try {
                    tempirature_changed =
                        tempirature_change(temperature_display, tempirature_scale, std::stoi(tempirature_input_line.toPlainText().toStdString()), from_dialog);
                } catch (std::exception& e) {
                    return;
                }
                bool humidity_changed = false;
                try {
                    humidity_changed =
                        humidity_change(humidity_display, std::stoi(humidity_input_line.toPlainText().toStdString()));
                } catch (std::exception& e) {
                    return;
                }
                bool pressure_changed = false;
                try {
                    pressure_changed =
                        pressure_change(pressure_display, pressure_scale, std::stoi(pressure_input_line.toPlainText().toStdString()), pressure_button);
                } catch (std::exception& e) {
                    return;
                }
                if(!tempirature_changed || !humidity_changed || !pressure_changed) {
                    if (first_setup) {
                        temperature_display.setText("");
                        humidity_display.setText("");
                        pressure_display.setText("");
                    }
                    return;
                }
                if (first_setup) {
                    first_setup = false;
                    power_button.click();
                }
                dialog_window.close();
            });

            dialog_window.exec();
        });

    /******************************************************PLUS BUTTON***************************************************************/

    QObject::connect(&plus_button, &QPushButton::clicked, [&temperature_display, &tempirature_scale](){
        tempirature_change (temperature_display, tempirature_scale, 1);
    });
    /******************************************************MINUS BUTTON***************************************************************/
    QObject::connect(&minus_button, &QPushButton::clicked, [&temperature_display, &tempirature_scale](){
        tempirature_change (temperature_display, tempirature_scale, -1);
    });
    /******************************************************CHANGE SCALE BUTTONS***************************************************************/
    QObject::connect(&tempirature_scale_button, &QPushButton::clicked, [&temperature_display, &tempirature_scale, &tempirature_scale_button](){
        switch (tempirature_scale) {
        case 'C':
            tempirature_scale_button.setText("Scale F");
            tempirature_scale = 'F';
            break;
        case 'F':
            tempirature_scale_button.setText("Scale K");
            tempirature_scale = 'K';
            break;
        case 'K':
            tempirature_scale_button.setText("Scale C");
            tempirature_scale = 'C';
            break;
        }
        tempirature_scale_change (temperature_display, tempirature_scale);
    });

    QObject::connect(&pressure_button, &QPushButton::clicked,[&pressure_display, &pressure_scale, &pressure_button](){
        if (pressure_scale == "mmHg") {
            pressure_button.setText("kPa");
        } else if (pressure_scale == "kPa") {
            pressure_button.setText("mmHg");
        }
        pressure_scale_change (pressure_display, pressure_scale);
    });


/******************************************************FLOW DIRECTION BUTTON***************************************************************/
    QObject::connect(&flow_button, &QPushButton::clicked, [&flow_direction_display](){
        if (flow_direction_display.toPlainText() == "UP") {
            flow_direction_display.setText("RIGHT");
            flow_direction_display.setAlignment(Qt::AlignCenter);
        } else if (flow_direction_display.toPlainText() == "RIGHT") {
            flow_direction_display.setText("LEFT");
            flow_direction_display.setAlignment(Qt::AlignCenter);
        } else if (flow_direction_display.toPlainText() == "LEFT") {
            flow_direction_display.setText("UP");
            flow_direction_display.setAlignment(Qt::AlignCenter);
        }
    });

    w.show();
    QObject::connect(&a, &QApplication::aboutToQuit,[&flow_direction_display, &humidity_display, &pressure_display, &pressure_scale,
                                                    &temperature_display, &tempirature_scale, &first_setup](){
        if (!first_setup)
            to_write_a_log(temperature_display, tempirature_scale, pressure_display, pressure_scale, humidity_display, flow_direction_display);
    });
    return a.exec();
}
