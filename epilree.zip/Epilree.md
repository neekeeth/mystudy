Epilree.
This is the app for speed-up reading book. 
It just showing word by word of speed you turn at the start. Base it 1.3x speed, but you can turn it up to 3x - if it possible to you.

