/* EPILREE by NEEKEETH 01.2025*/
/*          V 3.0          */

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextEdit>
#include <QApplication>
#include <QtGui/qevent.h>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <QTimer>
#include <iostream>
#include <QVBoxLayout>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QFileDialog>

void print_text_by_pause (std::vector <std::string>& sourse_words, int counter, std::string& part_one, std::string& target_part, std::string& part_two) {
    if (counter - 71 < 0) {//71 magic digit
        for (size_t i = 0; i < counter; ++i) {
            part_one += sourse_words [i] + " ";
        }
    } else {
        part_one = "";
        for (size_t i = counter - 71; i < counter; ++i) {
            part_one += sourse_words [i] + " ";
        }
    }
    target_part = sourse_words[counter];
    if (counter == 0) {
        part_two = "";
    } else {
        if (part_two.length() > 170) part_two = "";//170 the same magic digits
        for (size_t i = counter + 1; i < counter + 71; ++i) {
            if (i >= sourse_words.size()) break;
            else {
                part_two += sourse_words [i] + " ";
            }
        }
    }
}

void to_do_after_screenplace_press (MainWindow& w, QLabel* name_of_slider, QPushButton* open_button, QPushButton* to_start_button, QLabel* speed_label,
                                   QTextEdit* book_progress_line, const size_t& words_counter, QTextEdit* text_part_one, QTextEdit* text_part_two,
                                   QTimer& new_timer, QSlider* reading_speed, int& counter, std::vector <std::string>& sourse_words,
                                    QTextEdit* target_line) {
    if(sourse_words.size() != 1) {
        if (new_timer.isActive()) {
            w.setStyleSheet("background-color: #fff;");
            new_timer.stop();
            name_of_slider -> show();
            reading_speed -> show();
            open_button -> show();
            to_start_button -> show();
            book_progress_line -> show();
            std::string part_one;
            std::string target_part;
            std::string part_two;
            print_text_by_pause(sourse_words, counter, part_one, target_part, part_two);
            text_part_one -> setPlainText((part_one).c_str());
            target_line -> setHtml(("<center>" + target_part + "</center>").c_str());
            target_line -> setStyleSheet("color:#006400;border: 0 px;");
            text_part_two -> setPlainText((part_two).c_str());
            book_progress_line -> setHtml(("<center> Word " + std::to_string(counter+1) + " of " + std::to_string(words_counter)+ "</center>").c_str());
            speed_label -> setText(std::to_string(reading_speed -> value()).c_str());
        } else {
            w.setStyleSheet("background-color: #000;");
            new_timer.start(reading_speed -> value());
            text_part_one -> setPlainText("");
            text_part_two -> setPlainText("");
            reading_speed -> hide();
            speed_label -> setText("");
            open_button -> hide();
            to_start_button -> hide ();
            name_of_slider -> hide ();
            book_progress_line -> hide();
        }
    }
}

void collect_the_book (std::vector <std::string>& words, std::vector <std::string>& sourse_words, size_t& words_counter, const std::string& path) {
    if (path == "") {
        words.clear();
        words_counter = 0;
        words.push_back("Press \"Open the book\" to start");
    } else {
        //if (PATH1 == PATH2 && sourse_words.size() != 0)...
        std::ifstream reader (path);//WE NEED THE PATH!
        std::string book_text = "";
        std::stringstream ss;

        if (reader.is_open()) {
            words.clear();
            words_counter = 0;
            while (reader >> book_text) {
                words.push_back(book_text);
            }
        }
    }
    sourse_words = words;
    words_counter = words.size();
    std::reverse(words.begin(), words.end());

}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    Ui::MainWindow new_ui;
    new_ui.setupUi(&w);
    QTextEdit* text_part_one = new_ui.text_edit_part_one;
    QTextEdit* text_part_two = new_ui.text_edit_part_two;
    QTextEdit* target_line = new_ui.target_line_edit;
    text_part_one -> setStyleSheet("color:#000; border: 0 px;");
    target_line -> setStyleSheet("color:#000;border: 0 px;");
    text_part_two -> setStyleSheet("color:#000;border: 0 px;");


    QTextEdit* book_progress_line = new_ui.progress_line_edit;
    QSlider* reading_speed = new_ui.reading_speed;
    QLabel* speed_label = new_ui.speed_label;
    QLabel* name_of_slider = new_ui.name_of_slider;
    QPushButton* open_button = new_ui.open_button;
    QPushButton* to_start_button = new_ui.to_start_button;
    book_progress_line -> setStyleSheet("color:#000;border: 0 px;");

    std::string path = "";
    std::vector <std::string> words;
    size_t words_counter = 0;
    std::vector <std::string> sourse_words;
    collect_the_book (words, sourse_words, words_counter, path);
    QTimer new_timer;
    int counter = 0;
    QObject::connect(&a, &QApplication::focusChanged, [speed_label, book_progress_line, &words_counter, text_part_one, text_part_two,
                                                       &new_timer, reading_speed, &counter, &sourse_words, target_line, to_start_button,
                                                       open_button, name_of_slider](){
        if (new_timer.isActive()) {
            new_timer.stop();
        }
        name_of_slider -> show();
        reading_speed -> show();
        open_button -> show();
        to_start_button -> show();
        book_progress_line -> show();
        std::string part_one;
        std::string target_part;
        std::string part_two;
        print_text_by_pause(sourse_words, counter, part_one, target_part, part_two);
        text_part_one -> setPlainText((part_one).c_str());
        target_line -> setHtml(("<center>" + target_part + "</center>").c_str());
        target_line -> setStyleSheet("color:#006400;border: 0 px;");
        text_part_two -> setPlainText((part_two).c_str());
        book_progress_line -> setHtml(("<center> Word " + std::to_string(counter+1) + " of " + std::to_string(words_counter)+ "</center>").c_str());
        speed_label -> setText(std::to_string(reading_speed -> value()).c_str());
    });
    QObject::connect(text_part_one, &QTextEdit::selectionChanged, [&w,name_of_slider, open_button, to_start_button, speed_label,
                                                                   book_progress_line, &words_counter, text_part_one, text_part_two,
                                                                   &new_timer, reading_speed, &counter, &sourse_words, target_line](){
        to_do_after_screenplace_press (w,name_of_slider, open_button, to_start_button, speed_label, book_progress_line, words_counter,
                                      text_part_one, text_part_two, new_timer, reading_speed, counter, sourse_words, target_line);
    });
    QObject::connect(text_part_two, &QTextEdit::selectionChanged, [&w,name_of_slider, open_button, to_start_button, speed_label,
                                                                   book_progress_line, &words_counter, text_part_one, text_part_two,
                                                                   &new_timer, reading_speed, &counter, &sourse_words, target_line](){
        to_do_after_screenplace_press (w,name_of_slider, open_button, to_start_button, speed_label, book_progress_line, words_counter,
                                      text_part_one, text_part_two, new_timer, reading_speed, counter, sourse_words, target_line);
    });

    QObject::connect(target_line, &QTextEdit::selectionChanged, [&w,name_of_slider, open_button, to_start_button, speed_label,
                                                                 book_progress_line, &words_counter, text_part_one, text_part_two,
                                                                 &new_timer, reading_speed, &counter, &sourse_words, target_line](){
        to_do_after_screenplace_press (w,name_of_slider, open_button, to_start_button, speed_label, book_progress_line, words_counter,
                                      text_part_one, text_part_two, new_timer, reading_speed, counter, sourse_words, target_line);
    });
    QObject::connect(&new_timer, &QTimer::timeout,[reading_speed, speed_label, open_button, to_start_button, text_part_one, text_part_two,
                                                    &words, &counter, target_line](){
        target_line -> setHtml(("<center>" + words.back() + "</center>").c_str());
        target_line -> setStyleSheet("color:#fff;border: 0 px;");
        ++counter;
        words.pop_back();
    });

    QObject::connect(reading_speed, &QSlider::valueChanged, [speed_label](int new_speed_value){
        speed_label -> setText(std::to_string(new_speed_value).c_str());
    });

    //CLICK TO THE START BUTTON
    QObject::connect(to_start_button, &QPushButton::clicked,[&counter, &words, &sourse_words, &words_counter, &a, text_part_one, text_part_two, &path](){
        counter = 0;
        collect_the_book (words, sourse_words, words_counter, path);
        a.focusChanged(text_part_one, text_part_two);//idk how can i say 'kostyl'' in english...
    });
    //CLICK TO OPEN BUTTON
    QObject::connect(open_button, &QPushButton::clicked,[to_start_button, &counter, &words, &sourse_words, &words_counter, &a,
                                                          text_part_one, text_part_two, &path](){
        path = "";
        QString file_path = QFileDialog::getOpenFileName(nullptr,
            "open your txt-version book",
            "/"
            "Media files (*.txt)");
        path = file_path.toStdString();
        collect_the_book (words, sourse_words, words_counter, path);
        to_start_button->clicked();
    });

    w.show();
    return a.exec();


    delete (reading_speed);
    delete (text_part_one);
    delete (text_part_two);
    delete (target_line);
}
